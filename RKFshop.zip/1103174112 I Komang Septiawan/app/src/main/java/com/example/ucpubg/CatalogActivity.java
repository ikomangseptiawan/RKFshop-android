package com.example.ucpubg;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CatalogActivity extends AppCompatActivity {

    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_catalog);
//        toolbar = findViewById(R.id.include);


        listView = findViewById(R.id.lis);

        // Buat adapter dan pasangkan ke listView
        listView.setAdapter(new CatalogAdapter(getData(), this));

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                // ambil posisi yg diklik
                Produk clicked = (Produk) listView.getItemAtPosition(position);

                Intent intent2 = new Intent(getApplicationContext(),
                        DataCatalog.class);
                intent2.putExtra("produk", clicked.getProduk());
                intent2.putExtra("harga", clicked.getHarga());
                intent2.putExtra("stok", clicked.getStok());
                intent2.putExtra("email",Preferences.getLoggedInUser(getBaseContext()));
//                intent2.putExtra("avatar",image);
                startActivity(intent2);
            }
        });

        Log.d("cek email",Preferences.getLoggedInUser(getBaseContext()));
        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setSelectedItemId(R.id.homeMenu);
        navigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.homeMenu:
//                        Intent a = new Intent(getApplicationContext(), CatalogActivity.class);
//                        startActivity(a);
                        break;
                    case R.id.historyMenu:
                        Intent b = new Intent(getApplicationContext(), HistoryActivity.class);
                        startActivity(b);
                        break;
                    case R.id.accountMenu:
                        Intent c = new Intent(getApplicationContext(), AccountActivity.class);
                        startActivity(c);
                        break;
                }
                return false;
            }
        });
    }

    void navBot(){

    }

    private List<Produk> getData() {
        Produk[] produks = new Produk[] {
                new Produk("100 UC", 25000, "available"),
                new Produk("250 UC", 49000, "available"),
                new Produk("600 UC", 115000, "available"),
                new Produk("800 UC", 160000, "available"),
                new Produk("1000 UC", 180000, "available"),
                new Produk("1800 UC", 325000, "available"),
                new Produk("2000 UC", 400000, "available"),
                new Produk("4000 UC", 800000, "available"),
        };

        return new ArrayList<>(Arrays.asList(produks));
    }
}
