package com.example.ucpubg;

public class Transaksi {
    String produkname,emailuser;
    Integer jumlah,total;
    byte[] bukti;

//    public Transaksi(String produkname, Integer jumlah, Integer total, String emailuser, byte[] butki) {
//        this.produkname = produkname;
//        this.emailuser = emailuser;
//        this.jumlah = jumlah;
//        this.total = total;
//        this.bukti = butki;
//    }

    public String getProdukname() {
        return produkname;
    }

    public void setProdukname(String produkname) {
        this.produkname = produkname;
    }

    public Integer getJumlah() {
        return jumlah;
    }

    public void setJumlah(Integer jumlah) {
        this.jumlah = jumlah;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public byte[] getBukti() {
        return bukti;
    }

    public void setBukti(byte[] bukti) {
        this.bukti = bukti;
    }

    public String getEmailuser() {
        return emailuser;
    }

    public void setEmailuser(String emailuser) {
        this.emailuser = emailuser;
    }
}
