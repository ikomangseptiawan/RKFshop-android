package com.example.ucpubg;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class Database extends SQLiteOpenHelper {
    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "ucpubg.db";

    // User table name
    private static final String TABLE_USER = "user";
    private static final String TABLE_TRANSACTION = "transaksi";

    // User Table Columns names
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_USER_NAME = "user_name";
    private static final String COLUMN_USER_EMAIL = "user_email";
    private static final String COLUMN_USER_PASSWORD = "user_password";

    // Transaksi Table Columns names
    private static final String COLUMN_TRANSACTION_ID = "id_trans";
    private static final String COLUMN_TRANSACTION_ID_USER = "user_email";
    private static final String COLUMN_TRANSACTION_PRODUKNAME = "produkname";
    private static final String COLUMN_TRANSACTION_TOTAL = "total";
    private static final String COLUMN_TRANSACTION_JUMLAH = "jumlah";
    private static final String COLUMN_TRANSACTION_BUKTI = "bukti";

    // create table sql query
    private String CREATE_USER_TABLE = "CREATE TABLE " + TABLE_USER + "("
            + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_USER_NAME + " TEXT,"
            + COLUMN_USER_EMAIL + " TEXT,"
            + COLUMN_USER_PASSWORD + " TEXT" + ")";

    private String CREATE_TRANSACTION_TABLE = "CREATE TABLE " + TABLE_TRANSACTION + "("
            + COLUMN_TRANSACTION_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
            + COLUMN_TRANSACTION_PRODUKNAME + " TEXT,"
            + COLUMN_TRANSACTION_ID_USER + " TEXT,"
            + COLUMN_TRANSACTION_TOTAL + " INTEGER,"
            + COLUMN_TRANSACTION_JUMLAH + " INTEGER,"
            + COLUMN_TRANSACTION_BUKTI + " BLOB" + ")";

    // drop table sql query
    private String DROP_USER_TABLE = "DROP TABLE IF EXISTS " + TABLE_USER;
    private String DROP_TRANSACTION_TABLE = "DROP TABLE IF EXISTS " + TABLE_TRANSACTION;

    public Database(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(CREATE_USER_TABLE);
        db.execSQL(CREATE_TRANSACTION_TABLE);
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        //Drop User Table if exist
        db.execSQL(DROP_USER_TABLE);
        db.execSQL(DROP_TRANSACTION_TABLE);

        // Create tables again
        onCreate(db);

    }

    public void addUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_NAME, user.getName());
        values.put(COLUMN_USER_EMAIL, user.getEmail());
        values.put(COLUMN_USER_PASSWORD, user.getPassword());

        // Inserting Row
        db.insert(TABLE_USER, null, values);
        db.close();
    }

    public void addTransaction(Transaksi transaksi) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_TRANSACTION_ID_USER, transaksi.getEmailuser());
        values.put(COLUMN_TRANSACTION_PRODUKNAME, transaksi.getProdukname());
        values.put(COLUMN_TRANSACTION_JUMLAH, transaksi.getJumlah());
        values.put(COLUMN_TRANSACTION_TOTAL, transaksi.getTotal());
        values.put(COLUMN_TRANSACTION_BUKTI, transaksi.getBukti());

        // Inserting Row
        db.insert(TABLE_TRANSACTION, null, values);
        db.close();
    }

    public List<User> getAllUser(String email) {

        List<User> userList = new ArrayList<User>();

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM "+TABLE_USER
                +" WHERE "+COLUMN_USER_EMAIL+" = '"+email+"'", null);


        // Traversing through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                User user = new User();
                user.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_USER_ID))));
                user.setName(cursor.getString(cursor.getColumnIndex(COLUMN_USER_NAME)));
                user.setEmail(cursor.getString(cursor.getColumnIndex(COLUMN_USER_EMAIL)));
                user.setPassword(cursor.getString(cursor.getColumnIndex(COLUMN_USER_PASSWORD)));
                // Adding user record to list
                userList.add(user);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        // return user list
        return userList;
    }
    public List<Transaksi> getAllTransaction(String email) {
        List<Transaksi> transaksis = new ArrayList<Transaksi>();

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM "+TABLE_TRANSACTION
                +" WHERE "+COLUMN_TRANSACTION_ID_USER+" = '"+email+"'", null);

        // Traversing through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Transaksi transaksi = new Transaksi();
                transaksi.setEmailuser(cursor.getString(cursor.getColumnIndex(COLUMN_TRANSACTION_ID_USER)));
                transaksi.setProdukname(cursor.getString(cursor.getColumnIndex(COLUMN_TRANSACTION_PRODUKNAME)));
                transaksi.setJumlah(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_TRANSACTION_JUMLAH))));
                transaksi.setTotal(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_TRANSACTION_TOTAL))));
                transaksi.setBukti(cursor.getBlob(cursor.getColumnIndex(COLUMN_TRANSACTION_BUKTI)));
                // Adding user record to list
                transaksis.add(transaksi);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        // return user list
        return transaksis;
    }

    public void updateUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_NAME, user.getName());
        values.put(COLUMN_USER_EMAIL, user.getEmail());
        values.put(COLUMN_USER_PASSWORD, user.getPassword());

        // updating row
        db.update(TABLE_USER, values, COLUMN_USER_ID + " = ?",
                new String[]{String.valueOf(user.getId())});
        db.close();
    }

    public void deleteUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        // delete user record by id
        db.delete(TABLE_USER, COLUMN_USER_ID + " = ?",
                new String[]{String.valueOf(user.getId())});
        db.close();
    }

    public boolean checkUser(String email) {

        // array of columns to fetch
        String[] columns = {
                COLUMN_USER_ID
        };
        SQLiteDatabase db = this.getReadableDatabase();

        // selection criteria
        String selection = COLUMN_USER_EMAIL + " = ?";

        // selection argument
        String[] selectionArgs = {email};

        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                      //filter by row groups
                null);                      //The sort order
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();

        if (cursorCount > 0) {
            return true;
        }

        return false;
    }

    public boolean checkUser(String email, String password) {

        // array of columns to fetch
        String[] columns = {
                COLUMN_USER_ID
        };
        SQLiteDatabase db = this.getReadableDatabase();
        // selection criteria
        String selection = COLUMN_USER_EMAIL + " = ?" + " AND " + COLUMN_USER_PASSWORD + " = ?";

        // selection arguments
        String[] selectionArgs = {email, password};

        Cursor cursor = db.query(TABLE_USER, //Table to query
                columns,                    //columns to return
                selection,                  //columns for the WHERE clause
                selectionArgs,              //The values for the WHERE clause
                null,                       //group the rows
                null,                       //filter by row groups
                null);                      //The sort order

        int cursorCount = cursor.getCount();

        cursor.close();
        db.close();
        if (cursorCount > 0) {
            return true;
        }

        return false;
    }

}
